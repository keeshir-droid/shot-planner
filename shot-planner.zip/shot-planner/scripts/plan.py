"""shot-planner: turn beats.json into a shot plan.

Usage:
    python plan.py beats.json --out shot_plan
    python plan.py beats.json --out shot_plan --picks picks.json
    python plan.py --show-rules
"""

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import engine  # noqa: E402
import render  # noqa: E402
from validate import BeatsError, validate  # noqa: E402

SKILL_DIR = os.path.dirname(HERE)
DIVIDER = "=" * 8 + " FOR CLAUDE ONLY, NOT FOR THE CREATOR " + "=" * 8


def load_picks(path):
    """picks.json looks like {"overhead_desk": {"title": "...", "url": "https://..."}}."""
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    picks = {}
    for key, v in raw.items():
        if isinstance(v, dict) and str(v.get("url", "")).startswith(("http://", "https://")) and v.get("title"):
            picks[key] = {"title": str(v["title"]), "url": v["url"]}
        else:
            print("Ignoring picks[%r]: needs a 'title' and an http(s) 'url'." % key, file=sys.stderr)
    return picks


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="Make a shot plan from beats.json")
    ap.add_argument("beats", nargs="?", help="path to beats.json")
    ap.add_argument("--out", default="shot_plan", help="folder for the results (default: shot_plan)")
    ap.add_argument("--rules", default=os.path.join(SKILL_DIR, "rules", "default.json"))
    ap.add_argument("--picks", help="picks.json with example links Claude found by searching the web")
    ap.add_argument("--show-rules", action="store_true", help="print the rules in use and exit")
    ap.add_argument("--quiet", action="store_true", help="do not print the plan")
    ap.add_argument("--dev", action="store_true", help="also write plan.json (full rule traces, for developers)")
    args = ap.parse_args(argv)

    rules = engine.load_json(args.rules)
    if args.show_rules:
        print(json.dumps(rules, indent=2))
        return 0
    if not args.beats:
        ap.error("give the path to beats.json")

    library = engine.load_json(os.path.join(SKILL_DIR, "reference", "library.json"))
    broll = engine.load_json(os.path.join(SKILL_DIR, "reference", "shots.json"))["shots"]
    for e in broll:
        library[e["id"]] = e
    known_topics = set(x for e in broll for x in e["topics"])

    try:
        with open(args.beats, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        print("Could not read %s: %s" % (args.beats, exc), file=sys.stderr)
        return 2
    try:
        data, warnings = validate(data, known_topics)
    except BeatsError as exc:
        print("beats.json needs fixing (%d problem(s)):" % len(exc.errors), file=sys.stderr)
        for e in exc.errors:
            print("  - " + e, file=sys.stderr)
        return 1
    for w in warnings:
        print("Note for Claude: " + w, file=sys.stderr)

    picks = load_picks(args.picks) if args.picks else {}
    plan = engine.plan(data, rules, [], broll=broll, library=library, picks=picks)
    plan_json = None
    if args.dev:
        plan_json = json.dumps(plan, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    names = render.write_all(plan, rules, library, args.out, plan_json)
    if not args.quiet:
        print(render.plan_md(plan, rules, library))
    print("Saved to %s: %s" % (os.path.abspath(args.out), ", ".join(names)))
    missing = [r for r in plan["reference_requests"] if r["key"] not in picks]
    if missing:
        print("\n" + DIVIDER)
        print("If you can search the web: search once for each look below, pick ONE real result that clearly shows it,")
        print("write picks.json as {\"<key>\": {\"title\": \"...\", \"url\": \"...\"}} using only URLs you actually saw in the")
        print("results, then rerun with --picks picks.json and show that final plan. If you can't search, ignore this.")
        for r in missing:
            print("  %s  (%s)  search: %s" % (r["key"], r["name"], r["query"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
