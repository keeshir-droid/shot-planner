"""The shot-planner rules engine. Standard library only, no randomness.

Same beats + same rules = byte-identical plan. Every decision about a shot
goes through Shot.set(), which records which rule made it and why in plain
words. "No trace, no change."
"""

import hashlib
import json

SETUPS = {
    "A": {
        "name": "Main spot",
        "where": "Phone on the tripod at eye level, about an arm's length plus a bit (1-1.5 m) from you.",
        "frame": "Vertical, 1x lens, 4K if your phone has it. Frame yourself from head to waist (waist-up).",
    },
    "B": {
        "name": "Wide spot",
        "where": "Same tripod, moved back until your whole body fits, or switch to the 0.5x lens.",
        "frame": "Vertical, 4K if you can. Leave a little room above your head.",
    },
    "C": {
        "name": "Detail spot",
        "where": "Phone close to the thing you are showing (hands, keyboard, product), on the tripod or propped steady.",
        "frame": "Vertical, 1x lens (or macro). Fill the frame with the object.",
    },
    "D": {
        "name": "Overhead spot",
        "where": "Phone pointing straight down at your desk from above (tripod with a horizontal arm, or a stack of books at the desk edge).",
        "frame": "Vertical. Keep your hands and the things you work with inside the frame.",
    },
    "E": {
        "name": "Over-the-shoulder spot",
        "where": "Phone on the tripod behind and a little above your shoulder, so your screen is visible past your head.",
        "frame": "Vertical. Check that the screen text is readable.",
    },
    "F": {
        "name": "Room spot",
        "where": "Phone on the tripod or a shelf, back far enough to show the scene (desk, window, street, mirror), held completely still.",
        "frame": "Vertical, 1x or 0.5x lens. Press record, then step into the scene.",
    },
    "G": {
        "name": "Low spot",
        "where": "Phone on the floor or a low tripod, tilted up toward you.",
        "frame": "Vertical. You stand or sit about a metre back.",
    },
    "I": {
        "name": "Side-angle spot",
        "where": "Phone on the tripod beside your laptop at 45 degrees to you, about a metre away, at eye height.",
        "frame": "Vertical. You, your desk and a bit of the laptop in frame.",
    },
    "J": {
        "name": "Laptop-level spot",
        "where": "Phone on the desk just behind your open laptop, low, looking across it at you.",
        "frame": "Vertical. The laptop sits softly blurred at the edge of the frame.",
    },
    "H": {
        "name": "Close wide-angle spot",
        "where": "Phone on the tripod about 40 cm from your face.",
        "frame": "Vertical, 0.5x lens, so your face looks big and expressive.",
    },
}
NO_CAMERA = {"screen_record": "Screen recording", "stock": "Stock footage", "graphic": "Graphic or text card"}
SIZE_NAMES = {"CU": "Face close-up", "MCU": "Head and shoulders", "MS": "Waist up", "WS": "Full body", "INSERT": "Detail shot"}
FLASHY = ("whip pan", "hand-over-lens")
PUSH_IN = "slow push-in"

# Fields every shot must explain if they differ from these values.
TRACED_DEFAULTS = {"dur_f": 0, "size": None, "setup": None, "source": None, "shot_type": None,
                   "movement": "static", "transition_in": "hard cut", "film_note": ""}


def lerp(pair, t):
    return pair["calm"] + (pair["punchy"] - pair["calm"]) * t


def load_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def derive(rules, energy):
    """Turn energy 1-5 into the numbers every pass uses."""
    t = (energy - 1) / 4.0
    pace, cut, mov, tr = rules["pace"], rules["cutaways"], rules["movement"], rules["transitions"]
    return {
        "energy": energy,
        "fps": rules["fps"],
        "wps": lerp(pace["words_per_sec"], t),
        "comma_pause": lerp(pace["comma_pause_s"], t),
        "sentence_pause": lerp(pace["sentence_pause_s"], t),
        "max_shot_s": lerp(pace["max_shot_s"], t),
        "first_shot_max_s": lerp(pace["first_shot_max_s"], t),
        "cutaway_budget": lerp(cut["budget_share"], t),
        "cutaway_len_s": lerp(cut["length_s"], t),
        "movement_share": lerp(mov["share"], t),
        "flashy_max": int(lerp(tr["flashy_max"], t) + 0.5),
    }


class Shot(object):
    def __init__(self, shot_id, track, beat, text):
        self.id = shot_id
        self.track = track          # "main" (the picture you see) or "overlay" (cutaway over it)
        self.beat_id = beat["id"]
        self.intent = beat["intent"]
        self.intensity = beat["intensity"]
        self.speaker = beat["speaker"]
        self.delivery = beat["delivery"]
        self.beat_delivery = beat["delivery"]   # what the script says; delivery can change if a line becomes action footage
        self.text = text
        self.start_f = 0
        self.picture = None         # what is shown, for non-speaker shots
        self.anchor_word = None
        self.trace = []
        for k, v in TRACED_DEFAULTS.items():
            setattr(self, k, v)

    def set(self, field, value, rule, because, outcome="decided"):
        for earlier in self.trace:
            if earlier["field"] == field and earlier["outcome"] == "decided":
                earlier["outcome"] = "superseded"       # a later rule replaced this decision
        setattr(self, field, value)
        self.trace.append({"rule": rule, "outcome": outcome, "field": field,
                           "value": value, "because": because})

    def note(self, rule, because, outcome, field=None, value=None):
        """Record a decision that did not change the shot (rejected, flagged)."""
        self.trace.append({"rule": rule, "outcome": outcome, "field": field,
                           "value": value, "because": because})

    def to_dict(self):
        return {
            "id": self.id, "track": self.track, "beat_id": self.beat_id,
            "intent": self.intent, "intensity": self.intensity,
            "speaker": self.speaker, "delivery": self.delivery, "beat_delivery": self.beat_delivery, "text": self.text,
            "picture": self.picture, "start_f": self.start_f, "dur_f": self.dur_f,
            "size": self.size, "setup": self.setup, "source": self.source, "shot_type": self.shot_type,
            "movement": self.movement, "transition_in": self.transition_in,
            "film_note": self.film_note, "trace": self.trace,
        }


# ---------------------------------------------------------------- timing

def word_seconds(tok, p):
    """Seconds to say one word, including the pause its punctuation causes."""
    n = 2 if any(c.isdigit() for c in tok) else 1      # "$4,000" is said as ~2-3 words
    sec = n / p["wps"]
    clean = tok.rstrip("\"')]”’")
    if clean.endswith((".", "?", "!", "—")):
        sec += p["sentence_pause"]
    elif clean.endswith((",", ";", ":")):
        sec += p["comma_pause"]
    return sec


def _is_boundary(tokens, k):
    """Can we cut between word k-1 and word k without breaking a clause?"""
    prev = tokens[k - 1].rstrip("\"')]”’")
    if prev.endswith((",", ";", ":", ".", "?", "!", "—")):
        return True
    return tokens[k].lower().strip(",.") in ("and", "but", "so", "because", "then", "or")


def split_ranges(tokens, weights, lo, hi, limit, min_words):
    """Split words lo..hi into pieces no longer than limit seconds, at clause breaks."""
    total = sum(weights[lo:hi])
    if total <= limit or hi - lo < 2 * min_words:
        return [(lo, hi)]
    half = total / 2.0
    natural = [k for k in range(lo + min_words, hi - min_words + 1) if _is_boundary(tokens, k)]
    if not natural and total <= limit * 1.4:
        return [(lo, hi)]       # no clean place to cut and only slightly long: keep the line whole
    cands = natural or list(range(lo + min_words, hi - min_words + 1))

    def gap(k):
        return (abs(sum(weights[lo:k]) - half), k)
    k = min(cands, key=gap)
    return split_ranges(tokens, weights, lo, k, limit, min_words) + \
        split_ranges(tokens, weights, k, hi, limit, min_words)


def pass_timing_and_segmentation(beats, p, rules):
    """Pass 1+2: how long each line takes, and cut long lines into shots."""
    shots, beat_info = [], {}
    pace = rules["pace"]
    fps = p["fps"]
    for bi, beat in enumerate(beats):
        tokens = beat["text"].split()
        weights = [word_seconds(t, p) for t in tokens]
        if bi == 0:
            limit = p["first_shot_max_s"]
            why_limit = "the first shot must grab attention in %.1f s" % limit
        else:
            factor = pace["intent_length_factor"].get(beat["intent"], 1.0)
            limit = p["max_shot_s"] * factor
            why_limit = "max shot length is %.1f s for a %s line" % (limit, beat["intent"])
        ranges = split_ranges(tokens, weights, 0, len(tokens), limit, pace["min_split_words"])
        beat_start_idx = len(shots)
        for ri, (lo, hi) in enumerate(ranges):
            sec = sum(weights[lo:hi])
            if ri == len(ranges) - 1:
                sec += beat["pause_after_s"]
            frames = max(int(round(sec * fps)), 1)
            shot = Shot("S%02d" % (len(shots) + 1), "main", beat, " ".join(tokens[lo:hi]))
            shot.word_range = (lo, hi)
            shot.set("dur_f", frames, "timing.speech",
                     "%d words at %.1f words/sec plus pauses is about %.1f s." % (hi - lo, p["wps"], sec))
            if len(ranges) > 1:
                shot.note("segment.split",
                          "The whole line would run %.1f s, but %s, so it is cut at a natural pause into %d shots."
                          % (sum(weights), why_limit, len(ranges)), "split")
            shots.append(shot)
        beat_info[beat["id"]] = {"weights": weights, "tokens": tokens, "first": beat_start_idx,
                                 "last": len(shots) - 1}
    return shots, beat_info


def assign_starts(shots, fps):
    t = 0
    for s in shots:
        if s.track == "main":
            s.start_f = t
            t += s.dur_f
    return t


# ---------------------------------------------------------------- B-roll picker

PROP_WORDS = {"clip_on_mic": "a clip-on mic", "walkable_space": "space to walk through", "drink": "a drink",
              "screen": "something to screen-record"}


def _friendly(name):
    return PROP_WORDS.get(name, name.replace("_", " "))


class BrollPicker(object):
    """Matches what a line is about (its topics) to shots in the library, given what the creator has."""

    def __init__(self, entries, props, max_uses, max_spots=99, reuse_min_overlap=2, spots=("A",)):
        self.entries = [e for e in entries if e.get("kind", "broll") == "broll"]
        self.talking = [e for e in entries if e.get("kind") == "talking"]
        self.props = set(props)
        self.max_uses = max_uses
        self.max_spots = max_spots
        self.reuse_min_overlap = reuse_min_overlap
        self.spots = set(spots)         # phone positions already needed
        self.uses = {}
        self.last = None
        self.blocked = {}       # shot name -> what it needs, for the "tell me what you have" check

    def _missing(self, e):
        miss = [n for n in e.get("needs", []) if n not in self.props]
        any_ = e.get("needs_any", [])
        if any_ and not any(n in self.props for n in any_):
            miss.append(" or ".join(any_))
        return miss

    def choose(self, beat, avoid=()):
        """Return (entry or None, matched topics, rejection notes). avoid = shot ids that sit next to this spot."""
        topics = set(beat.get("topics", []))
        ranked = []
        for i, e in enumerate(self.entries):
            overlap = topics & set(e["topics"])
            if not overlap or (e.get("intents") and beat["intent"] not in e["intents"]):
                continue
            new_spot = 0 if (e["source"] != "shoot" or e["setup"] in self.spots) else 1
            screen_first = 0 if (beat["delivery"] == "voiceover" and e["source"] == "screen_record") else 1
            ranked.append((-len(overlap), screen_first, new_spot, self.uses.get(e["id"], 0), i, e, sorted(overlap)))
        ranked.sort(key=lambda r: r[:5])
        notes = []
        for _, _, _, used, _, e, overlap in ranked:
            if used and len(overlap) < self.reuse_min_overlap:
                continue                # only reuse a shot when the line is clearly about it
            miss = self._missing(e)
            if miss:
                self.blocked[e["name"]] = ", ".join(_friendly(m) for m in miss)
                notes.append("%s rejected: it needs %s, which you didn't list." % (e["name"], ", ".join(_friendly(m) for m in miss)))
                continue
            if used >= self.max_uses or e["id"] in avoid:
                continue
            if e["source"] == "shoot" and e["setup"] not in self.spots and len(self.spots) >= self.max_spots:
                notes.append("%s rejected: it would need another phone position, and the plan is capped at %d to keep the shoot quick." % (e["name"], self.max_spots))
                continue
            return e, overlap, notes
        return None, [], notes

    def choose_talking(self, beat, avoid=()):
        """Pick a different angle for a line the creator says on camera."""
        topics = set(beat.get("topics", []))
        ranked = []
        for i, e in enumerate(self.talking):
            if e.get("intents") and beat["intent"] not in e["intents"]:
                continue
            if not e.get("min_intensity", 1) <= beat["intensity"] <= e.get("max_intensity", 5):
                continue
            overlap = topics & set(e["topics"])
            if e.get("topic_required") and not overlap:
                continue
            new_spot = 0 if e["setup"] in self.spots else 1
            ranked.append((-len(overlap), new_spot, self.uses.get(e["id"], 0), i, e, sorted(overlap)))
        ranked.sort(key=lambda r: r[:4])
        notes = []
        for _, _, used, _, e, overlap in ranked:
            miss = self._missing(e)
            if miss:
                self.blocked[e["name"]] = ", ".join(_friendly(m) for m in miss)
                notes.append("%s rejected: it needs %s, which you didn't list." % (e["name"], ", ".join(_friendly(m) for m in miss)))
                continue
            if used > self.max_uses or e["id"] in avoid:
                continue
            if e["setup"] not in self.spots and len(self.spots) >= self.max_spots:
                notes.append("%s rejected: it would need another phone position, and the plan is capped at %d." % (e["name"], self.max_spots))
                continue
            return e, overlap, notes
        return None, [], notes

    def commit(self, e):
        self.uses[e["id"]] = self.uses.get(e["id"], 0) + 1
        self.last = e["id"]
        if e["source"] == "shoot":
            self.spots.add(e["setup"])


# ---------------------------------------------------------------- picture for voiceover

def _join(words):
    return ", ".join("'%s'" % w for w in words)


def _word_index(text, anchor):
    if not anchor:
        return None
    pos = text.lower().find(anchor.lower())
    return None if pos < 0 else len(text[:pos].split())


def pass_voiceover_picture(shots, beats, picker):
    """Voiceover lines have no speaker on screen, so the visuals ARE the picture."""
    by_id = dict((b["id"], b) for b in beats)
    last_visual = {}
    for s in shots:
        beat = by_id[s.beat_id]
        if s.delivery != "voiceover":
            continue
        lo, hi = s.word_range
        usable = [v for v in beat["visuals"] if v["kind"] != "abstract"]
        chosen = None
        for v in usable:
            wi = _word_index(beat["text"], v.get("anchor"))
            if wi is not None and lo <= wi < hi:
                chosen = v
                break
        if chosen is None:
            chosen = last_visual.get(beat["id"]) or (usable[0] if usable else None)
        if chosen is None:
            entry, matched, notes = picker.choose(beat, avoid={picker.last})
            for n in notes:
                s.note("broll.missing_prop", n, "rejected")
            if entry is not None:
                picker.commit(entry)
                _set_library_fields(s, entry, "broll.topic_match",
                                    "This line is about %s, so show %s." % (_join(matched), entry["name"].lower()))
                continue
            s.picture = "text card"
            s.set("source", "graphic", "picture.no_visual",
                  "This is a voiceover line with nothing listed to show, so a text card carries it.")
            s.set("size", "GRAPHIC", "picture.no_visual", "Text card on screen.")
            s.set("setup", "graphic", "picture.no_visual", "No camera needed for a text card.")
            continue
        last_visual[beat["id"]] = chosen
        s.picture = chosen["noun"] + ((" " + chosen["action"]) if chosen.get("action") else "")
        _set_visual_fields(s, chosen, "picture.voiceover",
                           "Voiceover line, so the picture is the %s." % chosen["noun"])


def _set_library_fields(s, e, rule, because):
    """Give a shot the look of a library shot (over-the-shoulder screen, overhead desk, ...)."""
    s.picture = e["name"]
    s.set("shot_type", e["id"], rule, because)
    s.set("source", e["source"], rule, "Filmed with your phone." if e["source"] == "shoot" else "Screen recording, no camera needed.")
    s.set("size", "SCREEN" if e["source"] == "screen_record" else "BROLL", rule, e["name"] + ".")
    s.set("setup", e["setup"], rule, "Phone position for this shot." if e["source"] == "shoot" else "No camera setup needed.")


def _set_visual_fields(s, v, rule, because):
    src = v["source"]
    s.set("source", src, rule, because)
    if src == "shoot":
        s.set("size", "INSERT", rule, "Close-up of the %s." % v["noun"])
        s.set("setup", "C", rule, "Filmed at the detail spot.")
    else:
        s.set("size", src.upper().replace("_RECORD", ""), rule,
              "Not filmed with your camera (%s)." % src.replace("_", " "))
        s.set("setup", src, rule, "No camera setup needed.")


# ---------------------------------------------------------------- size

def pass_size(shots, beats, p, rules, meta):
    """Pick a shot size for every on-camera shot, then work out how to record it."""
    by_id = dict((b["id"], b) for b in beats)
    size = rules["size"]
    ladder = list(size["ladder"])
    mic = meta["style"]["mic"]
    wide_ok = mic == "clip-on"
    prev = None
    for s in shots:
        if s.delivery != "on_camera":
            prev = None
            continue
        beat = by_id[s.beat_id]
        pin = beat["pin"].get("size")
        preferred = size["by_intensity"][str(beat["intensity"])]
        why = "Intensity %d out of 5 suggests %s." % (beat["intensity"], SIZE_NAMES[preferred].lower())
        if beat["intent"] in size["wide_intents"] and beat["intensity"] <= size["wide_max_intensity"]:
            preferred = "WS"
            why = "A calm %s line suits a full-body shot that shows the space." % beat["intent"]
        choice = preferred
        if pin:
            choice, why, rule = pin, "You asked for %s." % SIZE_NAMES[pin].lower(), "size.pin"
        else:
            rule = "size.match_emotion"
            if choice == "WS" and not wide_ok:
                s.note("size.mic_limit", "Full body rejected: with only the phone mic you need to stay close "
                       "for clean sound. A clip-on mic would allow it.", "rejected", "size", "WS")
                choice, why = "MS", "Waist-up instead, to stay close to the phone mic."
        allowed = [x for x in ladder if wide_ok or x != "WS"]
        if not pin and prev and prev["speaker"] == s.speaker and prev["size"] == choice:
            pi = allowed.index(choice)
            cands = [x for x in allowed if x != choice]
            tighter_first = beat["intensity"] >= 3
            cands.sort(key=lambda x: (abs(allowed.index(x) - pi),
                                      (allowed.index(x) > pi) if tighter_first else (allowed.index(x) < pi)))
            s.note("size.make_cut_visible",
                   "%s rejected: %s's previous shot was also %s, so cutting between them would look like "
                   "an accidental jump cut." % (SIZE_NAMES[choice], _speaker_label(meta, s.speaker),
                                                 SIZE_NAMES[choice].lower()), "rejected", "size", choice)
            choice, rule = cands[0], "size.make_cut_visible"
            why = "Stepped to %s so the cut between the two shots looks deliberate." % SIZE_NAMES[choice].lower()
        s.set("size", choice, rule, why)
        _set_setup(s, choice, size["crop_percent"])
        prev = {"speaker": s.speaker, "size": choice}


def _speaker_label(meta, sid):
    for sp in meta["speakers"]:
        if sp["id"] == sid:
            return sp.get("name", sid)
    return sid


def _set_setup(s, choice, crops):
    if choice == "WS":
        s.set("setup", "B", "setup.from_size", "Full body needs the phone further back (Setup B).")
    elif choice == "MS":
        s.set("setup", "A", "setup.from_size", "Waist-up is how Setup A is framed. No crop needed.")
    else:
        s.set("setup", "A", "setup.from_size", "%s is a %d%% punch-in of Setup A, done in editing."
              % (SIZE_NAMES[choice], crops[choice]))


# ---------------------------------------------------------------- cutaways

def pass_cutaways(shots, beats, beat_info, p, rules, total_f):
    """Overlay pictures on on-camera lines, timed to the spoken word."""
    cfg = rules["cutaways"]
    fps = p["fps"]
    budget = int(p["cutaway_budget"] * total_f)
    used = 0
    overlays = []
    last_end = -1
    for beat in beats:
        if beat["delivery"] != "on_camera":
            continue
        info = beat_info[beat["id"]]
        mains = shots[info["first"]:info["last"] + 1]
        beat_start = mains[0].start_f
        beat_end = mains[-1].start_f + mains[-1].dur_f
        for v in beat["visuals"]:
            if v["kind"] == "abstract":
                continue
            protected = beat["intent"] == cfg["protect_intent"] and beat["intensity"] >= cfg["protect_min_intensity"]
            if protected:
                mains[0].note("cutaway.protect_peak",
                              "Cutaway to the %s rejected: this is the strongest moment of the reel, so the "
                              "picture stays on your face." % v["noun"], "rejected")
                continue
            wi = _word_index(beat["text"], v.get("anchor"))
            offset = 0 if wi is None else int(round(sum(info["weights"][:wi]) * fps))
            length = int(round(p["cutaway_len_s"] * fps))
            start = beat_start + offset
            if start + length > beat_end:
                start = max(beat_start, beat_end - length)
            length = min(length, beat_end - start)
            if length < cfg["min_length_s"] * fps or start < last_end:
                mains[0].note("cutaway.no_room", "Cutaway to the %s rejected: not enough room on this line." % v["noun"], "rejected")
                continue
            if used + length > budget:
                mains[0].note("cutaway.budget",
                              "Cutaway to the %s rejected: cutaways are limited to %d%% of the reel's running time."
                              % (v["noun"], int(p["cutaway_budget"] * 100)), "rejected")
                continue
            o = Shot("B%d" % (len(overlays) + 1), "overlay", beat, beat["text"])
            o.start_f = start
            o.picture = v["noun"] + ((" " + v["action"]) if v.get("action") else "")
            o.set("dur_f", length, "cutaway.length", "Cutaways last about %.1f s at this energy." % p["cutaway_len_s"])
            when = ("when you say \"%s\"" % v["anchor"]) if wi is not None else "at the start of the line"
            _set_visual_fields(o, v, "cutaway.concrete_noun",
                               "You mention a %s, so show it %s. Your voice keeps playing over the picture." % (v["noun"], when))
            overlays.append(o)
            used += length
            last_end = start + length
    return overlays


def _neighbor_types(shots, at_f, skip=None):
    """Library shot types right before and after a moment, so the same one is never placed twice in a row."""
    typed = sorted((x for x in shots if x.shot_type and x is not skip), key=lambda x: (x.start_f, x.id))
    before = [x for x in typed if x.start_f <= at_f]
    after = [x for x in typed if x.start_f > at_f]
    out = set()
    if before:
        out.add(before[-1].shot_type)
    if after:
        out.add(after[0].shot_type)
    return out


def pass_topic_broll(shots, beats, beat_info, p, rules, total_f, overlays, picker):
    """Add a cutaway on spoken lines whose topic matches a library shot (laptop work, desk, reaction...)."""
    cfg, bcfg = rules["cutaways"], rules["broll"]
    fps = p["fps"]
    budget = int(p["cutaway_budget"] * total_f)
    used = sum(o.dur_f for o in overlays)
    occupied = [(o.start_f, o.start_f + o.dur_f) for o in overlays]
    new = []
    for beat in beats:
        if beat["delivery"] != "on_camera" or not beat.get("topics"):
            continue
        info = beat_info[beat["id"]]
        mains = shots[info["first"]:info["last"] + 1]
        beat_start = mains[0].start_f
        beat_end = mains[-1].start_f + mains[-1].dur_f
        if any(a < beat_end and b > beat_start for a, b in occupied):
            continue            # this line already has a cutaway from something you asked to show
        if any(s.delivery != "on_camera" for s in mains):
            continue            # part of this line is already shown as action footage
        start_guess = beat_start + int((beat_end - beat_start) * bcfg["topic_overlay_at"])
        entry, matched, notes = picker.choose(beat, avoid=_neighbor_types(shots + overlays + new, start_guess))
        for n in notes:
            mains[0].note("broll.missing_prop", n, "rejected")
        if entry is None:
            continue
        if beat["intent"] == cfg["protect_intent"] and beat["intensity"] >= cfg["protect_min_intensity"]:
            mains[0].note("cutaway.protect_peak", "%s rejected: the strongest moment of the reel stays on your face."
                          % entry["name"], "rejected")
            continue
        length = int(round(p["cutaway_len_s"] * fps))
        start = beat_start + int((beat_end - beat_start) * bcfg["topic_overlay_at"])
        if start + length > beat_end:
            start = max(beat_start, beat_end - length)
        length = min(length, beat_end - start)
        if length < cfg["min_length_s"] * fps or any(a < start + length and b > start for a, b in occupied):
            mains[0].note("cutaway.no_room", "%s rejected: not enough room on this line." % entry["name"], "rejected")
            continue
        if used + length > budget:
            mains[0].note("cutaway.budget", "%s rejected: cutaways are limited to %d%% of the reel's running time."
                          % (entry["name"], int(p["cutaway_budget"] * 100)), "rejected")
            continue
        o = Shot("B?", "overlay", beat, beat["text"])
        o.start_f = start
        o.set("dur_f", length, "cutaway.length", "Cutaways last about %.1f s at this energy." % p["cutaway_len_s"])
        _set_library_fields(o, entry, "broll.topic_match",
                            "This line is about %s, so cut away to %s. Your voice keeps playing over the picture."
                            % (_join(matched), entry["name"].lower()))
        picker.commit(entry)
        used += length
        occupied.append((start, start + length))
        new.append(o)
    return new


# ---------------------------------------------------------------- variety

def _is_plain(s):
    """You facing the lens at the main spot: the shot that makes a reel feel samey when there are too many."""
    return s.track == "main" and s.delivery == "on_camera" and s.shot_type is None


def _set_talking_fields(s, e, because):
    s.set("shot_type", e["id"], "variety.angle", because)
    s.set("size", e["size"], "variety.angle", e["name"] + ".")
    s.set("setup", e["setup"], "variety.angle", "Phone position for this shot.")


def plain_stats(shots):
    talking = [s for s in shots if s.track == "main" and s.beat_delivery == "on_camera"]
    return len([s for s in talking if _is_plain(s)]), len(talking)


def variety_limits(p, rules):
    cfg = rules["variety"]
    t = (p["energy"] - 1) / 4.0
    return lerp(cfg["max_plain_share"], t), max(1, int(lerp(cfg["max_plain_run"], t) + 0.5))


def pass_variety(shots, beats, p, rules, picker, overlays):
    """Swap in a different angle (or action footage) when too many shots in a row are the same plain talking head."""
    cfg = rules["variety"]
    cut_cfg = rules["cutaways"]
    max_share, max_run = variety_limits(p, rules)
    by_id = dict((b["id"], b) for b in beats)
    mains = [s for s in shots if s.track == "main"]
    blocked = set()

    def try_upgrade(s, why):
        beat = by_id[s.beat_id]
        if beat["pin"].get("size"):
            return False                    # the creator chose this one
        under_overlay = any(o.start_f < s.start_f + s.dur_f and o.start_f + o.dur_f > s.start_f for o in overlays)
        peak = beat["intent"] == cut_cfg["protect_intent"] and beat["intensity"] >= cut_cfg["protect_min_intensity"]
        talking = [x for x in mains if x.beat_delivery == "on_camera"]
        acted = len([x for x in talking if x.delivery == "voiceover"])
        room = acted < max(1, int(cfg["max_action_share"] * len(talking) + 0.5))   # keep the creator's face in the reel
        can_act = (room and not peak and not under_overlay and beat.get("topics") and beat["intent"] in cfg["convert_intents"]
                   and beat["intensity"] <= cfg["convert_max_intensity"])
        avoid = _neighbor_types(shots + overlays, s.start_f, skip=s)
        for kind in (["action", "angle"] if can_act else ["angle"]):
            if kind == "action":
                e, matched, notes = picker.choose(beat, avoid=avoid)
            else:
                e, matched, notes = picker.choose_talking(beat, avoid=avoid)
            for n in notes:
                s.note("broll.missing_prop", n, "rejected")
            if e is None:
                continue
            picker.commit(e)
            if kind == "action":
                s.delivery = "voiceover"
                _set_library_fields(s, e, "variety.action",
                                    "%s This line is about %s, so show it as %s and say the line out loud while you film it."
                                    % (why, _join(matched), e["name"].lower()))
            else:
                _set_talking_fields(s, e, "%s This line gets a different angle: %s." % (why, e["name"].lower()))
            return True
        return False

    def runs():
        out, cur = [], []
        for s in mains:
            if _is_plain(s):
                cur.append(s)
            else:
                if cur:
                    out.append(cur)
                cur = []
        if cur:
            out.append(cur)
        return out

    def centered(run):
        mid = len(run) // 2
        return sorted((x for x in run if x.id not in blocked), key=lambda x: (abs(run.index(x) - mid), run.index(x)))

    while True:
        plain, total = plain_stats(mains)
        all_runs = runs()
        long_runs = [r for r in all_runs if len(r) > max_run and any(x.id not in blocked for x in r)]
        if long_runs:
            why = "More than %d plain talking-to-camera shots in a row looks samey." % max_run
            cands = centered(long_runs[0])
        elif total >= 3 and plain / float(total) > max_share + 1e-9:
            why = "At this energy at most %d%% of your talking shots should be the plain straight-to-camera look." % int(max_share * 100)
            cands = [x for r in sorted(all_runs, key=lambda r: -len(r)) for x in centered(r)]
        else:
            break
        for s in cands:
            if try_upgrade(s, why):
                break
            blocked.add(s.id)
        else:
            break


# ---------------------------------------------------------------- movement

def pass_movement(shots, p, rules):
    cfg = rules["movement"]
    fps = p["fps"]
    cands = []
    for order, s in enumerate(shots):
        if (s.track == "main" and s.delivery == "on_camera" and s.shot_type is None and s.size != "WS"
                and s.intent in cfg["intents"] and s.intensity >= cfg["min_intensity"]
                and s.dur_f >= cfg["min_shot_s"] * fps):
            cands.append((-s.intensity, order, s))
    cands.sort(key=lambda c: (c[0], c[1]))
    oncam = len([s for s in shots if s.track == "main" and s.delivery == "on_camera"])
    n = int(p["movement_share"] * oncam + 0.5)
    n = max(n, 1) if cands and p["movement_share"] > 0 else n
    for i, (_, _, s) in enumerate(cands):
        if i < n:
            s.set("movement", PUSH_IN, "movement.build_tension",
                  "Intensity %d %s line, long enough to feel it: a slow push-in built in editing adds tension." % (s.intensity, s.intent))
        else:
            s.note("movement.budget", "Push-in skipped: movement is limited to about %d%% of shots at this energy."
                   % int(p["movement_share"] * 100), "rejected", "movement", PUSH_IN)


# ---------------------------------------------------------------- transitions

def pass_transitions(shots, p, rules):
    cfg = rules["transitions"]
    mains = [s for s in shots if s.track == "main"]
    flashy_used = 0
    prev_flashy = False
    for i, s in enumerate(mains):
        if i == 0:
            continue
        prev = mains[i - 1]
        new_line = s.beat_id != prev.beat_id
        both_cam = s.delivery == "on_camera" and prev.delivery == "on_camera"
        eligible = (new_line and both_cam and s.intent in cfg["flashy_intents"]
                    and i >= cfg["no_flashy_before_shot"] and not prev_flashy)
        if eligible and flashy_used < p["flashy_max"]:
            if s.setup != prev.setup:
                kind = "hand-over-lens"
                note = ("End this line by covering the lens with your hand. Start the next take with your "
                        "hand over the lens, then pull it away.")
            else:
                kind = "whip pan"
                note = "End this line with a quick swing of the phone sideways. Start the next line with a swing back."
            s.set("transition_in", kind, "transition.accent",
                  "A %s marks the move into the %s. Used %d of %d fancy transitions allowed at this energy."
                  % (kind, s.intent, flashy_used + 1, p["flashy_max"]))
            prev.set("film_note", note, "transition.accent", "Needed to film the %s into the next shot." % kind)
            flashy_used += 1
            prev_flashy = True
            continue
        prev_flashy = False
        if eligible:
            s.note("transition.budget", "Fancy transition skipped: at this energy the reel allows %d." % p["flashy_max"],
                   "rejected", "transition_in")
        if both_cam and s.speaker == prev.speaker and s.setup == prev.setup and s.size != prev.size:
            s.set("transition_in", "punch-in cut", "transition.punch_in",
                  "Same spot, different crop (%s to %s): the change in size hides the jump cut."
                  % (SIZE_NAMES[prev.size].lower(), SIZE_NAMES[s.size].lower()))
        elif s.setup != prev.setup and both_cam:
            s.note("transition.hard", "Plain cut: the phone moves between shots, so trim the gap in editing.", "decided")


# ---------------------------------------------------------------- checks

def pass_checks(shots, beats, p, rules, meta, total_f, picker=None):
    out = []
    fps = p["fps"]
    if beats[0]["intent"] != "hook":
        out.append({"code": "no_hook", "message": "The first line is not marked as a hook. The first 2-3 seconds decide if people keep watching."})
    if beats[-1]["intent"] != "cta":
        out.append({"code": "no_cta", "message": "No closing call to action (follow, comment, link). Add one if you want viewers to act."})
    for s in shots:
        if s.track == "main" and s.dur_f > p["max_shot_s"] * 1.3 * fps and s.dur_f > 0:
            out.append({"code": "long_shot", "message": "Shot %s runs %.1f s and could not be split further. Consider tightening the line or adding a pause-free cut in editing." % (s.id, s.dur_f / float(fps))})
    target = meta.get("target_duration_s")
    if target:
        actual = total_f / float(fps)
        if abs(actual - target) > rules["checks"]["duration_tolerance"] * target:
            out.append({"code": "duration", "message": "Estimated length is %.0f s but the target was %s s (speech timing is accurate to about 15%%)." % (actual, target)})
    plain, talking = plain_stats(shots)
    max_share, _ = variety_limits(p, rules)
    if talking >= 3 and plain / float(talking) > max_share + 1e-9:
        out.append({"code": "mostly_plain", "message": "%d of %d talking shots are still plain straight-to-camera ones. Tell me what's around you (laptop, desk, mirror, space to walk) or whether you have a clip-on mic, and I can add more angles." % (plain, talking)})
    spots = sorted(set(s.setup for s in shots if s.setup in SETUPS))
    if len(spots) > 5:
        out.append({"code": "many_setups", "message": "This reel uses %d different phone spots. That is a lot of moving around; drop a cutaway or two if you want a quicker shoot." % len(spots)})
    if picker is not None and picker.blocked:
        names = sorted(picker.blocked)[:3]
        out.append({"code": "missing_props", "message": "Some lines would suit extra shots (%s), but they need things you didn't list (%s). Tell me what you have around you and I'll add them." % (
            ", ".join(n.lower() for n in names), "; ".join(sorted(set(picker.blocked[n] for n in names))))})
    return out


# ---------------------------------------------------------------- run

def reference_requests(shots, broll_by_id, library, limit):
    """Which looks should Claude search the web for? One specific query each, in order of first use."""
    out, seen = [], set()
    for s in shots:
        keys = []
        if s.shot_type:
            keys.append(s.shot_type)
        if s.movement != "static":
            keys.append("push-in")
        if s.transition_in in FLASHY:
            keys.append(s.transition_in)
        for k in keys:
            if k in seen:
                continue
            seen.add(k)
            entry = broll_by_id.get(k) or library.get(k) or {}
            if entry.get("reference_query"):
                out.append({"key": k, "name": entry["name"], "query": entry["reference_query"]})
    return out[:limit]


def plan(data, rules, warnings, broll=None, library=None, picks=None):
    """data = validated beats. Returns a plan dict (ready to dump as plan.json)."""
    meta, beats = data["meta"], data["beats"]
    broll = list(broll or [])
    library = library or {}
    p = derive(rules, meta["style"]["energy"])
    props = list(meta["props"]) + (["clip_on_mic"] if meta["style"]["mic"] == "clip-on" else [])
    picker = BrollPicker(broll, props, rules["broll"]["max_uses_per_shot"], rules["broll"]["max_phone_spots"], rules["broll"]["reuse_min_overlap"])
    shots, beat_info = pass_timing_and_segmentation(beats, p, rules)
    total_f = assign_starts(shots, p["fps"])
    pass_voiceover_picture(shots, beats, picker)
    pass_size(shots, beats, p, rules, meta)
    overlays = pass_cutaways(shots, beats, beat_info, p, rules, total_f)
    pass_variety(shots, beats, p, rules, picker, overlays)
    overlays += pass_topic_broll(shots, beats, beat_info, p, rules, total_f, overlays, picker)
    overlays.sort(key=lambda o: o.start_f)
    for n, o in enumerate(overlays):
        o.id = "B%d" % (n + 1)
    pass_movement(shots, p, rules)
    pass_transitions(shots, p, rules)
    checks = pass_checks(shots + overlays, beats, p, rules, meta, total_f, picker)
    everything = sorted(shots + overlays, key=lambda s: (s.start_f, 0 if s.track == "main" else 1, s.id))
    digest = hashlib.sha1(json.dumps([data, rules, broll, picks or {}], sort_keys=True).encode("utf-8")).hexdigest()[:12]
    return {
        "schema_version": "1.0",
        "input_hash": digest,
        "meta": meta,
        "derived": dict((k, round(v, 3) if isinstance(v, float) else v) for k, v in sorted(p.items())),
        "total_frames": total_f,
        "fps": p["fps"],
        "shots": [s.to_dict() for s in everything],
        "setups": _setup_cards(everything),
        "reference_requests": reference_requests(everything, dict((e["id"], e) for e in broll), library,
                                                 rules["broll"]["max_reference_searches"]),
        "picks": picks or {},
        "warnings": list(warnings),
        "checks": checks,
    }


def _setup_cards(shots):
    """Group shots by where the phone must be."""
    cards = {}
    for s in shots:
        if s.setup is None:
            continue
        cards.setdefault(s.setup, []).append(s.id)
    order = [k for k in sorted(SETUPS) if k in cards] + sorted(k for k in cards if k not in SETUPS)
    return [{"setup": k, "shots": cards[k]} for k in order]
