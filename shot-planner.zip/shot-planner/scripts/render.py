"""Turns the plan into one readable document (shown in chat and saved as shot_plan.md)."""

import io
import os
from urllib.parse import quote_plus

from engine import NO_CAMERA, SETUPS, SIZE_NAMES

WHY_FIELD_ORDER = ["shot_type", "size", "transition_in", "movement", "source", "film_note", "setup", "dur_f"]


def stamp(frames, fps):
    secs = frames / float(fps)
    return "%d:%04.1f" % (int(secs // 60), secs % 60)


def is_spoken(s):
    return s["delivery"] == "on_camera" and s["track"] == "main"


def size_label(s, library):
    if s.get("shot_type"):
        return library[s["shot_type"]]["name"]
    return SIZE_NAMES.get(s["size"], (s["size"] or "").title())


def record_text(s):
    if s["setup"] in SETUPS:
        return "Setup %s, %s" % (s["setup"], SETUPS[s["setup"]]["name"].lower())
    return NO_CAMERA.get(s["setup"], "")


def what_it_looks_like(s, library):
    """One or two plain sentences saying what this shot looks like on screen."""
    if s.get("shot_type"):
        e = library[s["shot_type"]]
        parts = [e["looks"]]
        if e.get("creator"):
            parts.append("Style of %s." % e["creator"])
        if s["track"] == "overlay":
            parts.append("Shown over the main shot while your voice keeps going.")
        elif s["beat_delivery"] == "on_camera" and s["delivery"] == "voiceover":
            parts.append("You say the line out loud while you film this, so there's no face to camera here.")
    elif is_spoken(s):
        parts = [library[s["size"]]["looks"]]
    else:
        pic = s["picture"] or "the key words"
        if s["source"] == "shoot":
            parts = ["Close-up of the %s, filling the frame." % pic]
        elif s["source"] == "screen_record":
            parts = ["Screen recording of the %s." % pic]
        elif s["source"] == "stock":
            parts = ["Stock footage of the %s." % pic]
        else:
            parts = ["Text or graphic on screen." if pic == "text card" else "Graphic of the %s." % pic]
        if s["track"] == "overlay":
            parts.append("Shown over the main shot while your voice keeps going.")
    if s["movement"] != "static":
        parts.append(library["push-in"]["looks"])
    if s["transition_in"] in ("whip pan", "hand-over-lens"):
        parts.append("Cut in: %s" % library[s["transition_in"]]["looks"][0].lower() + library[s["transition_in"]]["looks"][1:])
    return " ".join(parts)


def line_text(s):
    """What goes in the 'line or picture' column."""
    words = s["text"].split()
    short = " ".join(words[:7]) + ("..." if len(words) > 7 else "")
    if is_spoken(s):
        return '"%s"' % s["text"]
    if s.get("shot_type"):
        if s["track"] == "overlay":
            return 'Over: "%s"' % short
        label = "Say while filming" if s["beat_delivery"] == "on_camera" else "Voiceover"
        return '%s: "%s"' % (label, s["text"])
    return s["picture"] or "text card"


def search_url(query):
    return "https://www.youtube.com/results?search_query=" + quote_plus(query)


def pick_link(key, picks, library=None):
    """A real video Claude found, or (if none) a specific YouTube search so the cell is never empty."""
    pick = picks.get(key)
    if not pick:
        query = (library or {}).get(key, {}).get("reference_query")
        return "[Search examples](%s)" % search_url(query) if query else ""
    title = pick["title"] if len(pick["title"]) <= 45 else pick["title"][:42] + "..."
    return "[%s](%s)" % (title.replace("[", "(").replace("]", ")"), pick["url"])


def link_cell(s, picks, library):
    keys = [s.get("shot_type"), "push-in" if s["movement"] != "static" else None,
            s["transition_in"] if s["transition_in"] in ("whip pan", "hand-over-lens") else None]
    return " ".join(x for x in (pick_link(k, picks, library) for k in keys if k) if x) or "n/a"


def why_text(s, limit=2):
    decided = [t for t in s["trace"] if t["outcome"] in ("decided", "split", "inserted")
               and t["rule"] not in ("timing.speech", "setup.from_size")
               and not (t["rule"] == "broll.topic_match" and t["field"] != "shot_type")]
    decided.sort(key=lambda t: WHY_FIELD_ORDER.index(t["field"]) if t["field"] in WHY_FIELD_ORDER else 99)
    seen, out = set(), []
    for t in decided:
        if t["because"] not in seen:
            seen.add(t["because"])
            out.append(t["because"])
    return " ".join(out[:limit])


def cell(text):
    return text.replace("|", "/").replace("\n", " ")


def plan_md(plan, rules, library):
    fps = plan["fps"]
    meta = plan["meta"]
    st = meta["style"]
    shots = plan["shots"]
    mains = [s for s in shots if s["track"] == "main"]
    overlays = [s for s in shots if s["track"] == "overlay"]
    total = plan["total_frames"] / float(fps)
    positions = [c for c in plan["setups"] if c["setup"] in SETUPS]
    picks = plan.get("picks", {})

    L = ["# Shot plan: %s" % meta["title"], "",
         "About **%.0f seconds**, **%d shots**, **%d cutaways**, **%d phone position%s**." % (
             total, len(mains), len(overlays), len(positions), "" if len(positions) == 1 else "s"), "",
         "## How I read your script", "",
         "- Energy **%d of 5** (%s). Shots average about %.1f seconds." % (
             st["energy"], "calm" if st["energy"] <= 2 else "punchy" if st["energy"] >= 4 else "balanced",
             total / max(len(mains), 1)),
         "- Mic: **%s**%s" % (st["mic"], "." if st["mic"] == "clip-on" else ". Full-body shots are skipped so you can stay close for clean sound.")]
    talking = [s for s in mains if s["beat_delivery"] == "on_camera"]
    plain = [s for s in talking if s["delivery"] == "on_camera" and not s.get("shot_type")]
    if talking:
        L.append("- Variety: %d of your %d talking shots are the plain straight-to-camera look; the rest are different angles or action shots." % (len(plain), len(talking)))
    if st.get("notes"):
        L.append("- Your notes: %s" % st["notes"])

    L += ["", "## Your shots", "",
          "| Shot | Time | Look | What it looks like | Line or picture | Example |",
          "|---|---|---|---|---|---|"]
    for s in shots:
        label = ("↳ " if s["track"] == "overlay" else "") + s["id"]
        line = line_text(s)
        L.append("| %s | %s | %s | %s | %s | %s |" % (
            label, stamp(s["start_f"], fps), size_label(s, library), cell(what_it_looks_like(s, library)),
            cell(line), link_cell(s, picks, library)))
    L += ["", "*Example links are real videos found by searching when available. \"Search examples\" opens a YouTube search for that look.*"]

    shot_by_id = dict((s["id"], s) for s in shots)
    L += ["", "## How to film it", "",
          "Record everything in one sitting. Only move the phone when a position below says so. "
          "Most shots are crops you make in editing."]
    if st["mic"] == "phone":
        L.append("Sound tip: you're using the phone mic, so stay close to the phone.")
    n = 0
    for card in plan["setups"]:
        k = card["setup"]
        L.append("")
        if k in SETUPS:
            n += 1
            L += ["### Position %d: %s" % (n, SETUPS[k]["name"]), "",
                  "- **Where:** " + SETUPS[k]["where"],
                  "- **Frame:** " + SETUPS[k]["frame"],
                  "- **%s:**" % ("Say these lines" if k in ("A", "B") else "Film these")]
        else:
            L += ["### No camera needed: %s" % NO_CAMERA.get(k, k), "", "- **Get these ready:**"]
        for sid in card["shots"]:
            s = shot_by_id[sid]
            what = ('"%s"' % s["text"]) if is_spoken(s) else s["picture"]
            if s.get("shot_type"):
                e = library[s["shot_type"]]
                if is_spoken(s):
                    what = '"%s" **%s.** %s' % (s["text"], e["name"], e["how"])
                elif s["track"] == "main":
                    what = '**%s.** %s Say: "%s"' % (e["name"], e["how"], s["text"])
                else:
                    what = "**%s.** %s" % (e["name"], e["how"])
            crop = ""
            if is_spoken(s) and s["size"] in ("CU", "MCU") and not s.get("shot_type"):
                crop = " (punch in to %d%% when editing)" % rules["size"]["crop_percent"][s["size"]]
            L.append("  - %s (%s): %s%s" % (sid, stamp(s["start_f"], fps), what, crop))
            if s["film_note"]:
                L.append("    - *While filming:* " + s["film_note"])

    tricky = []
    for s in shots:
        for key in ("push-in" if s["movement"] != "static" else None,
                    s["transition_in"] if s["transition_in"] in ("whip pan", "hand-over-lens") else None):
            if key and key not in tricky:
                tricky.append(key)
    if tricky:
        L += ["", "## Moves worth a closer look", ""]
        for key in tricky:
            e = library[key]
            row = "- **%s:** %s %s" % (e["name"], e["what"], e["how"])
            link = pick_link(key, picks, library)
            L.append(row + ((" Example: " + link) if link else ""))

    L += ["", "## Why each shot looks this way", ""]
    for s in shots:
        w = why_text(s)
        if w:
            L.append("- **%s:** %s" % (s["id"], w))

    notes = [c["message"] for c in plan["checks"]] + plan["warnings"]
    if notes:
        L += ["", "## Heads up", ""] + ["- " + n for n in notes]
    return "\n".join(L) + "\n"


def write_all(plan, rules, library, out_dir, plan_json=None):
    os.makedirs(out_dir, exist_ok=True)
    files = {"shot_plan.md": plan_md(plan, rules, library)}
    if plan_json is not None:
        files["plan.json"] = plan_json
    for name, text in files.items():
        with io.open(os.path.join(out_dir, name), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
    return sorted(files)
