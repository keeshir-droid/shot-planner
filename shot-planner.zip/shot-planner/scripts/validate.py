"""Checks beats.json and fills in defaults.

Errors are written so Claude can fix the file and rerun: each one names the
place in the file and says what to change.
"""

INTENTS = ["hook", "setup", "point", "proof", "payoff", "cta"]
DELIVERIES = ["on_camera", "voiceover"]
VISUAL_KINDS = ["object", "screen", "place", "person", "graphic", "abstract"]
VISUAL_SOURCES = ["shoot", "screen_record", "stock", "graphic"]
MICS = ["phone", "clip-on"]
PROPS = ["laptop", "desk", "window", "drink", "notebook", "mirror", "product", "money", "walkable_space", "screen"]


class BeatsError(Exception):
    def __init__(self, errors):
        self.errors = errors
        Exception.__init__(self, "\n".join(errors))


def _enum(errors, path, value, allowed):
    if value not in allowed:
        errors.append("%s: %r is not allowed. Use one of: %s." % (path, value, ", ".join(allowed)))


def validate(data, known_topics=None):
    """Return (normalized_beats_dict, warnings). Raise BeatsError on problems.

    known_topics: topic words the shot library understands, used to warn about words that will not match anything."""
    errors, warnings = [], []
    if not isinstance(data, dict):
        raise BeatsError(["$: the file must be a JSON object with 'meta' and 'beats'."])

    meta = data.get("meta") or {}
    if not isinstance(meta, dict):
        errors.append("$.meta: must be an object.")
        meta = {}
    style = meta.get("style") or {}
    if not isinstance(style, dict):
        errors.append("$.meta.style: must be an object like {\"energy\": 3}.")
        style = {}

    energy = style.get("energy", 3)
    if not isinstance(energy, int) or isinstance(energy, bool) or not 1 <= energy <= 5:
        errors.append("$.meta.style.energy: must be a whole number from 1 (calm) to 5 (punchy), got %r." % (energy,))
        energy = 3
    mic = style.get("mic", "phone")
    _enum(errors, "$.meta.style.mic", mic, MICS)

    props = meta.get("props", [])
    if not isinstance(props, list) or not all(isinstance(x, str) for x in props):
        errors.append("$.meta.props: must be a list of words for what the creator has, e.g. [\"laptop\", \"desk\"].")
        props = []
    props = [x.strip().lower() for x in props]
    for x in props:
        if x not in PROPS:
            warnings.append("$.meta.props: %r is not a known prop and will be ignored. Known: %s." % (x, ", ".join(PROPS)))
    props = [x for x in props if x in PROPS]

    speakers = meta.get("speakers") or [{"id": "A", "name": "You"}]
    if not isinstance(speakers, list) or not all(isinstance(s, dict) and "id" in s for s in speakers):
        errors.append("$.meta.speakers: must be a list like [{\"id\": \"A\", \"name\": \"Maya\"}].")
        speakers = [{"id": "A", "name": "You"}]
    speaker_ids = [s["id"] for s in speakers]

    beats = data.get("beats")
    if not isinstance(beats, list) or not beats:
        raise BeatsError(errors + ["$.beats: must be a non-empty list of beats."])

    seen_ids = set()
    out_beats = []
    for i, b in enumerate(beats):
        p = "$.beats[%d]" % i
        if not isinstance(b, dict):
            errors.append("%s: must be an object." % p)
            continue
        for key in ("id", "text", "intent", "intensity", "delivery"):
            if key not in b:
                errors.append("%s: missing required field '%s'." % (p, key))
        if "id" in b:
            if b["id"] in seen_ids:
                errors.append("%s.id: %r is used twice. Give every beat its own id (b1, b2, ...)." % (p, b["id"]))
            seen_ids.add(b["id"])
        if "text" in b and (not isinstance(b["text"], str) or not b["text"].strip()):
            errors.append("%s.text: must be the spoken words of this beat, not empty." % p)
        if "intent" in b:
            _enum(errors, p + ".intent", b["intent"], INTENTS)
        if "delivery" in b:
            _enum(errors, p + ".delivery", b["delivery"], DELIVERIES)
        if "intensity" in b:
            v = b["intensity"]
            if not isinstance(v, int) or isinstance(v, bool) or not 1 <= v <= 5:
                errors.append("%s.intensity: must be a whole number 1-5, got %r." % (p, v))

        beat = dict(b)
        beat.setdefault("speaker", speaker_ids[0])
        beat.setdefault("pause_after_s", 0.0)
        beat.setdefault("visuals", [])
        beat.setdefault("pin", {})
        topics = beat.get("topics", [])
        if not isinstance(topics, list) or not all(isinstance(x, str) for x in topics):
            errors.append("%s.topics: must be a list of single words describing what the line is about, e.g. [\"coding\", \"laptop\"]." % p)
            topics = []
        beat["topics"] = [x.strip().lower() for x in topics]
        if known_topics is not None:
            for x in beat["topics"]:
                if x not in known_topics:
                    warnings.append("%s.topics: %r is not a word the shot library knows, so it will not match any shot." % (p, x))
        if beat["speaker"] not in speaker_ids:
            warnings.append("%s.speaker: %r is not listed in meta.speakers." % (p, beat["speaker"]))
        if not isinstance(beat["pause_after_s"], (int, float)) or beat["pause_after_s"] < 0:
            errors.append("%s.pause_after_s: must be a number of seconds, 0 or more." % p)
            beat["pause_after_s"] = 0.0

        if not isinstance(beat["visuals"], list):
            errors.append("%s.visuals: must be a list." % p)
            beat["visuals"] = []
        for j, v in enumerate(beat["visuals"]):
            vp = "%s.visuals[%d]" % (p, j)
            if not isinstance(v, dict):
                errors.append("%s: must be an object." % vp)
                continue
            v.setdefault("kind", "object")
            v.setdefault("source", "shoot")
            _enum(errors, vp + ".kind", v["kind"], VISUAL_KINDS)
            _enum(errors, vp + ".source", v["source"], VISUAL_SOURCES)
            if "noun" not in v:
                errors.append("%s: missing 'noun' (what is shown, e.g. \"invoice\")." % vp)
            anchor = v.get("anchor")
            if anchor and isinstance(b.get("text"), str) and anchor.lower() not in b["text"].lower():
                warnings.append("%s.anchor: %r is not in the beat's text, so the cutaway will start at the beginning of the line." % (vp, anchor))
                v["anchor"] = None

        if not isinstance(beat["pin"], dict):
            errors.append("%s.pin: must be an object like {\"size\": \"WS\"}." % p)
            beat["pin"] = {}
        elif "size" in beat["pin"]:
            _enum(errors, p + ".pin.size", beat["pin"]["size"], ["CU", "MCU", "MS", "WS"])
        out_beats.append(beat)

    if errors:
        raise BeatsError(errors)

    meta = dict(meta)
    meta["speakers"] = speakers
    meta["props"] = props
    meta["style"] = {"energy": energy, "mic": mic, "notes": style.get("notes", "")}
    meta.setdefault("title", "Untitled reel")
    return {"meta": meta, "beats": out_beats}, warnings
