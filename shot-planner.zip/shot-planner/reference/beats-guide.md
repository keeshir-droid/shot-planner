# How to write beats.json

A **beat** is one spoken idea: usually one sentence, sometimes two short ones. Keep the creator's exact words in `text`. Never rewrite, shorten or paraphrase. The planner splits long beats into shots by itself.

## File shape

```json
{
  "schema_version": "1.0",
  "meta": {
    "title": "short name of the reel",
    "target_duration_s": 45,
    "language": "en",
    "speakers": [{"id": "A", "name": "Maya"}],
    "props": ["laptop", "desk", "drink"],
    "style": {"energy": 4, "mic": "phone", "notes": "what the creator asked for, in their words"}
  },
  "beats": [ ... ]
}
```

- `energy`: 1 calm explainer ... 3 balanced ... 5 fast and punchy. Change this when asked to speed up or slow down.
- `mic`: `phone` or `clip-on`.
- `speakers`: one entry per person talking. Use ids A, B. Leave out for a single speaker.
- `props`: what the creator has around them that can appear on camera. Allowed words: `laptop`, `desk`, `window`, `drink`, `notebook`, `mirror`, `product`, `money`, `walkable_space`, `screen` (they can screen-record). Only list what they said or clearly implied; B-roll that needs something not listed is skipped.
- `target_duration_s`: only if the creator said how long it should be.

## Each beat

| Field | Required | Values |
|---|---|---|
| `id` | yes | `b1`, `b2`, ... unique |
| `text` | yes | the exact words |
| `intent` | yes | `hook` (opening line), `setup` (context), `point` (a claim or step), `proof` (evidence, demo, example), `payoff` (the result or punchline), `cta` (call to action) |
| `intensity` | yes | 1-5. How emotionally strong the line is. 1 = background fact, 3 = normal, 5 = the biggest moment. Use 5 sparingly (once or twice a reel). |
| `delivery` | yes | `on_camera` (the creator is seen saying it) or `voiceover` (said over other pictures) |
| `speaker` | no | id from `speakers`; default is the first |
| `pause_after_s` | no | a held beat of silence after the line, e.g. 0.3 |
| `topics` | no, but add them | 1-4 lowercase words for what the line is about; see the list below |
| `visuals` | no | things worth showing during the line (below) |
| `pin` | no | `{"size": "CU" \| "MCU" \| "MS" \| "WS"}` only when the creator asks for a specific size |

The first beat should be the `hook` and the last should usually be the `cta`.

## Visuals

List each concrete thing the line mentions that can be shown:

```json
{"anchor": "one invoice", "noun": "invoice", "action": "crumpled", "kind": "object", "source": "shoot"}
```

- `anchor`: the exact words in `text` when the picture should appear (must match the text).
- `noun`: what is shown. `action`: what it's doing (optional).
- `kind`: `object`, `screen`, `place`, `person`, `graphic`, or `abstract` (ideas that can't be shown, like "freedom". These are skipped).
- `source`: `shoot` (they film it), `screen_record`, `stock`, or `graphic`.
- Ask the creator what they can actually film or record. If they don't know, prefer `screen_record` or `graphic` for digital things and `shoot` only for objects they own.
- On `voiceover` beats the visuals ARE the picture, so list them. On `on_camera` beats they become short cutaways.

## Checklist before running

- Every spoken word is in some beat's `text`, in order.
- Beat 1 is a hook; the last beat is a cta (if they have one).
- Intensities vary. A reel of all 3s or all 5s feels flat.
- Two speakers talking to one camera: give each beat the right `speaker`.

## Topics

`topics` is how the planner picks B-roll that fits the line (a laptop shot for a coding line, a reaction for a mistake). Use these words; others will not match anything. Tag EVERY beat with 2 to 4 words, even ones that look like plain talking: ask what could be shown while the line plays (the thing, the place, the feeling, the action). Beats with no tags only get generic fillers. Include a mood or action word (thinking, process, mistake, success) when no object fits. Skip beats that are only the creator talking to camera with nothing to show.

`achievement`, `ai`, `app`, `arrival`, `big`, `budget`, `building`, `buy`, `calm`, `challenge`, `city`, `claude`, `coding`, `coffee`, `commute`, `computer`, `confidence`, `cost`, `count`, `craft`, `dashboard`, `day`, `days`, `demo`, `design`, `desk`, `disaster`, `editing`, `email`, `embarrassing`, `emotion`, `fail`, `fashion`, `fitness`, `funny`, `getting-ready`, `goals`, `going`, `gym`, `home`, `hustle`, `idea`, `journal`, `journey`, `keyboard`, `laptop`, `launch`, `leaving`, `list`, `long`, `loss`, `making`, `memory`, `mistake`, `money`, `mood`, `morning`, `moving`, `night`, `nostalgia`, `notes`, `numbers`, `office`, `outfit`, `outside`, `plan`, `planning`, `power`, `price`, `problem`, `process`, `product`, `productivity`, `progress`, `proud`, `quiet`, `reaction`, `reflection`, `regret`, `research`, `result`, `reveal`, `routine`, `screen`, `self`, `setup`, `shock`, `software`, `spend`, `start`, `startup`, `story`, `study`, `success`, `surprise`, `time`, `tool`, `tools`, `travel`, `tutorial`, `typing`, `unboxing`, `waiting`, `walk`, `website`, `win`, `work`, `working`, `workspace`, `writing`, `wrong`

Examples: "I describe what I want to Claude and it writes the code" -> `["coding", "ai", "laptop"]`. "It broke fifty times" -> `["mistake", "fail", "problem"]`. "I wrote every idea down first" -> `["notes", "planning"]`. "Today it ships" -> `["success", "launch"]`.

The strongest moment (a hook at intensity 5) always stays on the creator's face, so no B-roll is added there.
